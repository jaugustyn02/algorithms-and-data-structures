from zad9testy import runtests

def highway( G,s ):
    # tu prosze wpisac wlasna implementacje
    return 0

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( maxflow, all_tests = False )