from zad4testy import runtests

def select_buildings(T,p):
    # tu prosze wpisac wlasna implementacje
    return [0]

runtests( select_buildings )