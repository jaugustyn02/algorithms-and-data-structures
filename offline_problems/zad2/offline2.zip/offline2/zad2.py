from zad2testy import runtests


def depth(L):
    # tu prosze wpisac wlasna implementacje
    pass


runtests( depth ) 
