from zad3testy import runtests

def SortTab(T,P):
    # tu prosze wpisac wlasna implementacje
    return

runtests( SortTab )