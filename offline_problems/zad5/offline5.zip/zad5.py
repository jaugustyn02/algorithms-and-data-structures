from zad5testy import runtests

def plan(T):
    # tu prosze wpisac wlasna implementacje
    return [0]

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( plan, all_tests = False )