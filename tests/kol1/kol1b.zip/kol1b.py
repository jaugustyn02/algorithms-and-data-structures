from kol1btesty import runtests

def f(T):
    # tu prosze wpisac wlasna implementacje
    return 0


# Zamien all_tests=False na all_tests=True zeby uruchomic wszystkie testy
runtests( f, all_tests=False )
