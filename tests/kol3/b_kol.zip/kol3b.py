from kol3btesty import runtests

def airports( G, A, s, t ):
    # tu prosze wpisac wlasna implementacje
    return None

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( airports, all_tests = False )